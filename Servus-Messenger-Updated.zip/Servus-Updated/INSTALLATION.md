# Installationsanleitung für Servus Messenger Update

## Voraussetzungen

Das Update erfordert die gleichen Voraussetzungen wie die ursprüngliche Installation:
- Python 3.8+
- PostgreSQL Datenbank
- Poetry (für Dependency-Management)

## Installation

### 1. Projekt aktualisieren

Ersetzen Sie die folgenden Dateien in Ihrem bestehenden Servus-Projekt:

**Backend-Dateien:**
- `app.py` - Neue API-Endpunkte für Profil-Updates
- `profile_api.py` - Neue Datei für Profil-Funktionen

**Frontend-Dateien:**
- `templates/chat.html` - Neue Modals und UI-Struktur
- `static/css/chat.css` - Verbesserte Styles mit Light-Mode
- `static/js/chat.js` - Kompatibel mit neuen Features
- `static/js/theme.js` - Neue Datei für Theme-Management
- `static/js/profile.js` - Neue Datei für Profil-Modal
- `static/js/sidebar.js` - Neue Datei für Seitenleisten-Navigation

**Assets:**
- `static/img/logo.png` - Neues Logo (Verzeichnis erstellen falls nicht vorhanden)

### 2. Datenbank-Migration ausführen

Kopieren Sie die neue Migrationsdatei:
- `sql/7.sql` - Fügt neue Spalten zur users-Tabelle hinzu

Die Migration wird automatisch beim nächsten Start von `app.py` ausgeführt, da das System automatisch alle neuen SQL-Dateien im `sql/`-Verzeichnis anwendet.

### 3. Abhängigkeiten überprüfen

Stellen Sie sicher, dass alle Python-Abhängigkeiten installiert sind:

```bash
poetry install
```

Die neuen Features benötigen keine zusätzlichen Python-Pakete.

### 4. Anwendung starten

```bash
poetry run python app.py
```

Die Anwendung wird automatisch die neue Datenbank-Migration ausführen und alle neuen Features sind sofort verfügbar.

## Überprüfung der Installation

Nach der Installation können Sie folgende Tests durchführen:

### Test 1: Theme-Umschaltung
1. Öffnen Sie die Anwendung
2. Klicken Sie auf das Einstellungen-Icon (⚙) in der Sidebar
3. Wählen Sie "Hell" aus dem Theme-Dropdown
4. Überprüfen Sie, dass sich das Design ändert
5. Aktualisieren Sie die Seite - das Theme sollte beibehalten werden

### Test 2: Akzentfarbe-Anpassung
1. Öffnen Sie die Einstellungen
2. Klicken Sie auf den Farbpicker
3. Wählen Sie eine neue Farbe
4. Überprüfen Sie, dass die Akzentfarbe überall in der UI aktualisiert wird

### Test 3: Profil-Bearbeitung
1. Klicken Sie auf Ihren Avatar in der Sidebar
2. Geben Sie einen Statustext ein
3. Wählen Sie einen Präsenzstatus
4. Klicken Sie auf "Speichern"
5. Überprüfen Sie, dass die Änderungen gespeichert werden

### Test 4: Anfragen-Sidebar
1. Klicken Sie auf den Anfragen-Button (✉) in der Sidebar
2. Überprüfen Sie, dass die Anfragen-Sidebar angezeigt wird
3. Klicken Sie auf "Zurück" um zur Chat-Liste zurückzukehren

### Test 5: Logo-Anzeige
1. Überprüfen Sie, dass das neue Logo in der Sidebar angezeigt wird
2. Öffnen Sie einen Chat und klicken Sie auf "Zurück"
3. Überprüfen Sie, dass das Logo im Placeholder angezeigt wird

## Troubleshooting

### Problem: Logo wird nicht angezeigt

**Lösung:** Stellen Sie sicher, dass die Datei `static/img/logo.png` existiert:
```bash
ls -la static/img/logo.png
```

Falls die Datei fehlt, kopieren Sie sie:
```bash
mkdir -p static/img
cp logo.png static/img/logo.png
```

### Problem: Einstellungen werden nicht gespeichert

**Lösung:** Überprüfen Sie, dass localStorage im Browser aktiviert ist. Dies ist normalerweise standardmäßig aktiviert. Falls deaktiviert, aktivieren Sie es in den Browser-Einstellungen.

### Problem: Datenbank-Migration schlägt fehl

**Lösung:** Überprüfen Sie die Datenbank-Verbindung und stellen Sie sicher, dass die `users`-Tabelle existiert. Falls Sie eine ältere Version verwenden, führen Sie zuerst alle früheren Migrationen aus.

### Problem: API-Endpunkte funktionieren nicht

**Lösung:** Stellen Sie sicher, dass Sie die neue Version von `app.py` verwenden und dass Sie die Anwendung neu gestartet haben.

## Rückwärtskompatibilität

Alle neuen Features sind vollständig rückwärtskompatibel:

- Bestehende Chats und Nachrichten funktionieren unverändert
- Neue Datenbank-Spalten haben Default-Werte
- Alte Browser ohne localStorage-Unterstützung funktionieren trotzdem
- Die Anwendung funktioniert auch ohne die neuen Features

## Support

Falls Sie auf Probleme stoßen, überprüfen Sie bitte:

1. Die Browser-Konsole auf JavaScript-Fehler (F12 → Console)
2. Die Server-Logs auf Python-Fehler
3. Die Datenbank-Verbindung
4. Dass alle Dateien korrekt kopiert wurden

## Weitere Informationen

Siehe `CHANGELOG.md` für eine detaillierte Liste aller Änderungen.
