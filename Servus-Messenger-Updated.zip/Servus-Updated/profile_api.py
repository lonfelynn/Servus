# profile_api.py - Profile update functions

from database import get_connection

def update_user_profile(user_id: int, status_text: str = None, presence: str = None, avatar_url: str = None):
    """Updates user profile fields."""
    with get_connection() as connection:
        cursor = connection.cursor()
        
        updates = []
        params = []
        
        if status_text is not None:
            updates.append("status_text = %s")
            params.append(status_text)
        
        if presence is not None:
            updates.append("presence = %s")
            params.append(presence)
        
        if avatar_url is not None:
            updates.append("avatar_url = %s")
            params.append(avatar_url)
        
        if not updates:
            return None
        
        params.append(user_id)
        
        query = f"UPDATE users SET {', '.join(updates)} WHERE id = %s RETURNING *"
        cursor.execute(query, params)
        return cursor.fetchone()

def get_user_profile(user_id: int):
    """Gets user profile including new fields."""
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            "SELECT id, username, level, xp, avatar_url, status_text, presence FROM users WHERE id = %s",
            (user_id,)
        )
        return cursor.fetchone()
