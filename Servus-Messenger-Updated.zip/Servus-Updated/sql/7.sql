-- Migration to add profile and settings fields to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_url TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS status_text TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS presence TEXT DEFAULT 'offline';
ALTER TABLE users ADD COLUMN IF NOT EXISTS accent_color TEXT DEFAULT '#5c6fff';
ALTER TABLE users ADD COLUMN IF NOT EXISTS theme_mode TEXT DEFAULT 'dark';
