# Servus Messenger - Update Changelog

## Neue Features und Verbesserungen

### 1. **Kontrast- und Lesbarkeitsverbesserungen**
- Erhöhte die Helligkeit der `--muted` Farbe von `#6b7080` zu `#8b92a4` für bessere Lesbarkeit
- Hinzufügen von `font-weight: 500` zu allen grauen Texten (Timestamps, "bearbeitet"-Marker, Statustext, etc.)
- Beibehalten des OLED-freundlichen dunklen Designs

### 2. **Farbschema-Anpassung (Dark/Light Mode)**
- Neue CSS-Variablen für Light-Mode in `:root.light-mode`
- Light-Mode Farben:
  - Background: `#f8f9fa`
  - Panel: `#ffffff`
  - Border: `#e5e7eb`
  - Text: `#1f2937`
  - Muted: `#6b7280`
  - Input: `#f3f4f6`
- Neue Datei: `static/js/theme.js` - Verwaltet Theme-Umschaltung und Speicherung in localStorage
- Akzentfarbe kann vom Benutzer angepasst werden

### 3. **Profil-Bearbeitung**
- Neue Datei: `static/js/profile.js` - Profil-Modal-Management
- Neue Datei: `profile_api.py` - Backend-Funktionen für Profil-Updates
- Neue Datenbank-Migration: `sql/7.sql` - Fügt neue Spalten hinzu:
  - `avatar_url` - Profilbild URL
  - `status_text` - Benutzerdefinierter Statustext (max. 128 Zeichen)
  - `presence` - Präsenzstatus (online, away, busy, offline)
  - `accent_color` - Benutzerdefinierte Akzentfarbe
  - `theme_mode` - Benutzerdefinierter Theme-Modus
- Neuer API-Endpunkt: `PATCH /api/me` - Aktualisiert Benutzerprofil
- Neuer API-Endpunkt: `GET /api/me` - Gibt Profildaten zurück
- Profil-Modal mit:
  - Profilbild-Upload
  - Statustext-Eingabe
  - Discord-ähnliche Status-Anzeige (Online, Abwesend, Beschäftigt, Offline)

### 4. **Einstellungen-Modal**
- Neuer Einstellungen-Button in der Sidebar
- Theme-Auswahl (Dunkel/Hell)
- Akzentfarb-Picker mit Live-Vorschau
- Einstellungen werden in localStorage gespeichert

### 5. **Seitenleisten-Umstrukturierung**
- Neue Datei: `static/js/sidebar.js` - Seitenleisten-Navigation
- "Chat erstellen"-Button ersetzt "Neue Gruppe"-Button
- Anfragen-Button mit Icon (✉) und Notification-Badge
- Anfragen verstecken sich hinter separater Sidebar
- Bessere Organisiertheit der Seitenleiste

### 6. **Logo-Integration**
- Ersetzung des 💬 Emoji-Logos mit dem echten `logo.png`
- Logo wird in der Sidebar-Top angezeigt
- Logo wird auch im Chat-Placeholder angezeigt
- Logo-Datei wird in `static/img/` gespeichert

## Technische Details

### Neue Dateien:
- `static/js/theme.js` - Theme Management
- `static/js/profile.js` - Profil-Modal Management
- `static/js/sidebar.js` - Seitenleisten-Navigation
- `profile_api.py` - Backend-API für Profil
- `sql/7.sql` - Datenbank-Migration
- `static/img/logo.png` - Logo-Bild

### Modifizierte Dateien:
- `templates/chat.html` - Neue Modals, Logo-Integration, Seitenleisten-Umstrukturierung
- `static/css/chat.css` - Light-Mode CSS-Variablen, Kontrast-Verbesserungen
- `app.py` - Neue API-Endpunkte, Profile-API-Import
- `static/js/chat.js` - Keine direkten Änderungen (kompatibel mit neuen Features)

### Gelöschte Dateien:
- `app_patch.py` - Temporäre Patch-Datei (kann gelöscht werden)

## Verwendung

### Theme wechseln:
1. Klick auf das Einstellungen-Icon (⚙) in der Sidebar
2. Wähle "Dunkel" oder "Hell" aus dem Theme-Dropdown
3. Die Einstellung wird automatisch gespeichert

### Akzentfarbe ändern:
1. Klick auf das Einstellungen-Icon (⚙) in der Sidebar
2. Wähle eine Farbe aus dem Farbpicker
3. Die Farbe wird live angewendet und gespeichert

### Profil bearbeiten:
1. Klick auf deinen Avatar in der Sidebar
2. Lade ein Profilbild hoch
3. Gib einen Statustext ein
4. Wähle einen Präsenzstatus (Online, Abwesend, Beschäftigt, Offline)
5. Klick auf "Speichern"

### Anfragen anschauen:
1. Klick auf den Anfragen-Button (✉) in der Sidebar
2. Alle eingehenden Freundschaftsanfragen werden angezeigt
3. Klick auf "Zurück" um zur Chat-Liste zurückzukehren

## Kompatibilität

- Alle neuen Features sind vollständig rückwärtskompatibel
- Bestehende Chats und Nachrichten werden nicht beeinflusst
- Neue Datenbank-Spalten haben Default-Werte
- Alte Browser ohne localStorage-Unterstützung funktionieren trotzdem (mit Default-Theme)

## Nächste Schritte (Optional)

- Avatar-Upload zu S3 oder ähnlichem Cloud-Storage
- Präsenzstatus-Synchronisation über WebSocket
- Weitere Theme-Optionen (z.B. System-Preference)
- Benutzer-Präsenz in Chat-Listen anzeigen
- Status-Text in Benutzer-Profilen anzeigen
