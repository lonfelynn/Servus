// sidebar.js - Sidebar Navigation Management

const mainSidebar = document.getElementById("sidebar");
const requestsSidebar = document.getElementById("requests-sidebar");
const requestsBtn = document.getElementById("requests-btn");
const backToChatsBtn = document.getElementById("back-to-chats-btn");
const newChatBtn = document.getElementById("new-chat-btn");
const newGroupBtn = document.getElementById("new-group-btn");

// Update button references if they exist
const groupModal = document.getElementById("group-modal");

// Show requests sidebar
requestsBtn.addEventListener("click", () => {
  mainSidebar.classList.add("hidden");
  mainSidebar.style.display = "none";
  requestsSidebar.classList.remove("hidden");
  requestsSidebar.style.display = "flex";
});

// Back to chats
backToChatsBtn.addEventListener("click", () => {
  requestsSidebar.classList.add("hidden");
  requestsSidebar.style.display = "none";
  mainSidebar.classList.remove("hidden");
  mainSidebar.style.display = "flex";
});

// Create chat menu - for now, just open the group modal
// In the future, this could be a dropdown with "Direct Message" and "Group Chat" options
newChatBtn.addEventListener("click", () => {
  if (groupModal) {
    // Trigger the group modal
    const event = new Event("click");
    document.getElementById("new-group-btn").dispatchEvent(event);
  }
});

// Make sure new-group-btn still works
if (newGroupBtn) {
  // The existing group modal logic will handle this
}
