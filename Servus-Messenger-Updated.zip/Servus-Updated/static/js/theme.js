// theme.js - Theme und Accent-Farbe Management

// Theme aus localStorage laden und anwenden
function loadTheme() {
  const savedTheme = localStorage.getItem('servus-theme') || 'dark';
  const savedAccent = localStorage.getItem('servus-accent') || '#5c6fff';
  
  applyTheme(savedTheme);
  applyAccent(savedAccent);
}

function applyTheme(theme) {
  const root = document.documentElement;
  if (theme === 'light') {
    root.classList.add('light-mode');
  } else {
    root.classList.remove('light-mode');
  }
  localStorage.setItem('servus-theme', theme);
}

function applyAccent(color) {
  const root = document.documentElement;
  root.style.setProperty('--user-accent', color);
  localStorage.setItem('servus-accent', color);
}

function toggleTheme() {
  const root = document.documentElement;
  const isLight = root.classList.contains('light-mode');
  applyTheme(isLight ? 'dark' : 'light');
}

function getTheme() {
  return document.documentElement.classList.contains('light-mode') ? 'light' : 'dark';
}

function getAccent() {
  return getComputedStyle(document.documentElement).getPropertyValue('--user-accent').trim();
}

// Theme beim Laden anwenden
loadTheme();
