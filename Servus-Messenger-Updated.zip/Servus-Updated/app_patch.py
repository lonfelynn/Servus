# This code should be inserted into app.py after the api_me function

@app.route("/api/me", methods=["PATCH"])
@login_required
def api_update_me():
    """Updates the current user's profile."""
    me = session["user_id"]
    data = request.get_json(silent=True) or {}
    
    status_text = (data.get("status_text") or "").strip()
    if len(status_text) > 128:
        return jsonify({"ok": False, "error": "Statustext darf hoechstens 128 Zeichen haben."}), 400
    
    presence = data.get("presence", "offline")
    if presence not in ["online", "away", "busy", "offline"]:
        return jsonify({"ok": False, "error": "Ungültiger Präsenzstatus."}), 400
    
    avatar_url = data.get("avatar_url")
    
    user = update_user_profile(
        me,
        status_text=status_text if status_text else None,
        presence=presence,
        avatar_url=avatar_url
    )
    
    if user is None:
        return jsonify({"ok": False, "error": "Profil konnte nicht aktualisiert werden."}), 400
    
    return jsonify({"ok": True, "user": dict(user)})
